from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample route
@app.route('/')
def home():
    return "Welcome to the deployed Python API!"

# Example route that handles POST data
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    x = data.get('x', 0)
    result = x * 2  # Dummy logic
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
